from fabric.api import env, run

#For your convenience, each server has been linked to it's client-Id by means of a role:env.roledefs['node1'] = ['grisou-14.nancy.grid5000.fr']
env.roledefs['node0'] = ['grisou-15.nancy.grid5000.fr']
env.roledefs['node2'] = ['grisou-10.nancy.grid5000.fr']

env.roledefs['all'] = ['grisou-14.nancy.grid5000.fr', 'grisou-15.nancy.grid5000.fr', 'grisou-10.nancy.grid5000.fr']

#Use env.hosts instead of roles if you want to execute actions on all hosts instead of being selective:
#env.hosts = [
#	"grisou-14.nancy.grid5000.fr",
#	"grisou-15.nancy.grid5000.fr",
#	"grisou-10.nancy.grid5000.fr",
#  ]



env.key_filename="./id_rsa"
env.use_ssh_config = True
env.ssh_config_path = './ssh-config'

def pingtest():
    run('ping -c 3 8.8.8.8')

def uptime():
    run('uptime')
